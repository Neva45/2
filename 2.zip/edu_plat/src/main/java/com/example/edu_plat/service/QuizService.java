package com.example.edu_plat.service;

import com.example.edu_plat.dto.*;
import com.example.edu_plat.exception.ResourceNotFoundException;
import com.example.edu_plat.model.Course;
import com.example.edu_plat.model.Question;
import com.example.edu_plat.model.Quiz;
import com.example.edu_plat.model.User;
import com.example.edu_plat.repository.CourseRepository;
import com.example.edu_plat.repository.QuizRepository;
import com.example.edu_plat.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class QuizService {

    private static final Logger log = LoggerFactory.getLogger(QuizService.class);

    private final QuizRepository quizRepository;
    private final CourseRepository courseRepository;
    private final UserRepository userRepository;

    public QuizService(QuizRepository quizRepository,
                       CourseRepository courseRepository,
                       UserRepository userRepository) {
        this.quizRepository = quizRepository;
        this.courseRepository = courseRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    public QuizResponse createQuiz(QuizRequest request, String teacherEmail) {
        User teacher = userRepository.findByEmail(teacherEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Teacher not found: " + teacherEmail));

        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + request.getCourseId()));

        // Проверка, что TEACHER создаёт тест только для своего курса
        if (!"ADMIN".equalsIgnoreCase(teacher.getRole())
                && !teacher.getId().equals(course.getTeacherId())) {
            throw new AccessDeniedException("You can create quizzes only for your own courses");
        }

        Quiz quiz = new Quiz();
        quiz.setTitle(request.getTitle());
        quiz.setCourse(course);

        List<Question> questions = request.getQuestions().stream().map(dto -> {
            Question q = new Question();
            q.setText(dto.getText());
            q.setCorrectAnswer(dto.getCorrectAnswer());
            q.setQuiz(quiz);
            return q;
        }).collect(Collectors.toList());

        quiz.setQuestions(questions);
        Quiz saved = quizRepository.save(quiz);
        log.info("Quiz created id={}, courseId={}, teacherId={}", saved.getId(), course.getId(), teacher.getId());
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public QuizResultResponse submitQuiz(Long quizId, QuizSubmissionRequest submission) {
        Quiz quiz = quizRepository.findById(quizId)
                .orElseThrow(() -> new ResourceNotFoundException("Quiz not found with id: " + quizId));

        List<Question> questions = quiz.getQuestions();
        int total = questions.size();
        int correctCount = 0;

        Map<Long, String> studentAnswers = submission.getAnswers();

        for (Question q : questions) {
            String studentAnswer = studentAnswers.get(q.getId());
            if (studentAnswer != null && studentAnswer.equalsIgnoreCase(q.getCorrectAnswer())) {
                correctCount++;
            }
        }

        boolean passed = total > 0 && ((double) correctCount / total) >= 0.5;
        log.info("Quiz {} submitted: {}/{} correct, passed={}", quizId, correctCount, total, passed);
        return new QuizResultResponse(total, correctCount, passed);
    }

    @Transactional(readOnly = true)
    public QuizResponse getQuizById(Long id) {
        Quiz quiz = quizRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Quiz not found with id: " + id));
        return toResponse(quiz);
    }

    private QuizResponse toResponse(Quiz quiz) {
        QuizResponse response = new QuizResponse();
        response.setId(quiz.getId());
        response.setTitle(quiz.getTitle());
        response.setCourseId(quiz.getCourse().getId());
        response.setQuestions(quiz.getQuestions().stream().map(q -> {
            QuestionResponse qr = new QuestionResponse();
            qr.setId(q.getId());
            qr.setText(q.getText());
            return qr;
        }).collect(Collectors.toList()));
        return response;
    }
}
package com.example.edu_plat.dto;

public interface CourseReportProjection {
    Long getId();
    String getTitle();
    Long getActiveCount();
}

package com.example.edu_plat.dto;

public class EnrollmentRequest {
    private Long courseId;

    public Long getCourseId() { return courseId; }
    public void setCourseId(Long courseId) { this.courseId = courseId; }
}

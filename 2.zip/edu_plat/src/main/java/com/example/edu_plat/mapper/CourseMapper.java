package com.example.edu_plat.mapper;

import com.example.edu_plat.dto.CourseRequest;
import com.example.edu_plat.dto.CourseResponse;
import com.example.edu_plat.model.Course;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CourseMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "teacherId", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "description", source = "summary") // Дублируем из summary в description для старой версии БД
    Course toEntity(CourseRequest request);

    @Mapping(target = "summary", source = "summary") // Явно указываем источник для ответа (сработает наш умный геттер)
    CourseResponse toResponse(Course course);
}

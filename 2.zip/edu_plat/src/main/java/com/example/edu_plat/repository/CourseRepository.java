package com.example.edu_plat.repository;

import com.example.edu_plat.dto.CourseReportProjection;
import com.example.edu_plat.model.Course;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.List;

public interface CourseRepository extends JpaRepository<Course, Long>, JpaSpecificationExecutor<Course> {

    // Пример пессимистической блокировки (PESSIMISTIC_WRITE) для предотвращения гонки потоков при обновлении курса
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT c FROM Course c WHERE c.id = :id")
    Optional<Course> findByIdWithPessimisticLock(@Param("id") Long id);

     @Query(value = 
        "SELECT c.id as Id, c.title as title, COUNT(e.id) as activeCount " +
        "FROM courses c " +
        "LEFT JOIN enrollments e ON c.id = e.course_id AND e.status = 'ACTIVE' " +
        "GROUP BY c.id, c.title", 
        nativeQuery = true)
    List<CourseReportProjection> getCoursesReport();
}